from nes_py.wrappers import JoypadSpace
import gym_super_mario_bros
from gym_super_mario_bros.actions import SIMPLE_MOVEMENT
import numpy as np
import cv2
from collections import deque


class MarioEnvironment:
    def __init__(self, env_name='SuperMarioBros-v0', frame_skip=4, stack_frames=4, render_mode='human'):
        self.env = gym_super_mario_bros.make(env_name)
        self.env = JoypadSpace(self.env, SIMPLE_MOVEMENT)
        self.frame_skip = frame_skip
        self.stack_frames = stack_frames
        self.frame_stack = deque(maxlen=stack_frames)
        self.n_actions = self.env.action_space.n
        self.state_shape = (stack_frames, 84, 84)
    
    def preprocess_frame(self, frame):
        pass
    
    def reset(self):
        pass
    
    def step(self, action):
        pass
    
    def render(self, mode='human'):
        return self.env.render()
    
    def close(self):
        self.env.close()

